// Diagnostic only; no faer production code is changed.
// Fixture formulas adapted from t4a-faer 2592bad, LAPACK validation tests:
// faer/src/linalg/tests/lapack_support.rs and linalg/svd/tests/lapack.rs.
// Original numerical-test adaptation: LAPACK 3.12.0 distributed with OpenBLAS
// 791b02a1a00c996b66a894f6df93421c53b62d80; BSD-3-Clause, see faer/COPYING.LAPACK.BSD.
// Copyright (c) 1992-2023 The University of Tennessee and The University
// of Tennessee Research Foundation. All rights reserved.
// Copyright (c) 2000-2023 The University of California Berkeley.
// Copyright (c) 2006-2023 The University of Colorado Denver.
// SPDX-License-Identifier: BSD-3-Clause
use faer::{c32, c64, Col, Mat, Par, ParShape, Spec};
use faer::dyn_stack::{MemBuffer, MemStack};
use faer::linalg::svd;
use std::panic::{catch_unwind, AssertUnwindSafe};

fn scratch() {
    macro_rules! check {
        ($t:ty, $one:expr) => {{
            for n in [0, 1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17, 31, 32, 33, 63, 64, 65, 126, 127, 128, 129, 255, 256, 257] {
                for threshold in [0, 1, 3, 4, 5, 8, 16, 32, 64, 127, 128, 129] {
                    for (want_u, want_v) in [(false,true),(true,false),(false,false),(true,true)] {
                        let a = Mat::<$t>::from_fn(n,n,|i,j| if i==0 && j==0 {$one} else {Default::default()});
                        let mut s=Col::<$t>::zeros(n);
                        let mut u=Mat::<$t>::zeros(n,n);
                        let mut v=Mat::<$t>::zeros(n,n);
                        let mut p=Spec::<svd::SvdParams,$t>::default(); p.recursion_threshold=threshold;
                        let mode=|want| if want {svd::ComputeSvdVectors::Thin} else {svd::ComputeSvdVectors::No};
                        let req=svd::svd_scratch::<$t>(n,n,mode(want_u),mode(want_v),ParShape::Seq,p);
                        let mut mem=MemBuffer::new(req);
                        let result=catch_unwind(AssertUnwindSafe(|| svd::svd(a.as_ref(),s.as_mut().as_diagonal_mut(),
                            if want_u {Some(u.as_mut())} else {None}, if want_v {Some(v.as_mut())} else {None},
                            Par::Seq, MemStack::new(&mut mem),p)));
                        println!("scratch {} n={n} threshold={threshold} U={want_u} V={want_v} bytes={} result={:?}",
                            stringify!($t),req.size_bytes(),result.as_ref().map(|x|x));
                        result.unwrap().unwrap();
                        assert!(s.is_all_finite());
                        assert!(!want_u || u.is_all_finite());
                        assert!(!want_v || v.is_all_finite());
                    }
                }
            }
        }};
    }
    check!(f32,1.0); check!(c32,c32::new(0.0,1.0)); check!(f64,1.0); check!(c64,c64::new(0.0,1.0));
}

fn main() { scratch(); }
