# SVD scratch sizing #73: local correctness evidence

Baseline: 2592bad8cef0bbba00d1ae31c0442ea6cf3c5310.
Candidate: uncommitted; source.patch contains the final two Rust-file changes.
Candidate checks: aarch64-apple-darwin, Homebrew Rust 1.98.1, LLVM 22.1.8.
No arithmetic, threshold or scheduling changes. No benchmark acceptance run.

Commands run at the faer workspace root with these environment variables:

```
CARGO_TARGET_DIR=/Users/pzb464/Documents/faer/target
CARGO_PROFILE_DEV_DEBUG=0
CARGO_INCREMENTAL=0
```

## Final candidate checks

| Log | Command | Observed result |
| --- | --- | --- |
| internal-green.log | `cargo test -p t4a-faer --lib --locked --offline test_divide_and_conquer_exact_scratch -- --nocapture` | Exit 0: both tests pass in 1.16s. |
| workspace-review.log | `cargo test --workspace --locked --offline` | Exit 101: 462 faer passes, three existing strict-triangle matmul failures, 138 ignored. Includes the four-scalar public regression and both new internal tests; stops before integration/doc/traits tests. |
| svd-family-review.log | `cargo test --workspace --lib --locked --offline linalg::svd::tests:: -- --include-ignored --nocapture --test-threads=1` | Exit 101: 77 pass, one existing #75 orthogonality failure; 18,172 attempted LAPACK calls, zero call failures. |
| format-baseline.log / format-check-review.log | `rustfmt --edition 2021 --config-path rustfmt.toml --config skip_children=true --check <the two SVD Rust files>` | Same three existing formatting differences. Reports match exactly after removing file/line headings; changed blocks match the formatter. |

The new sequential internal test executes 10,080 calls: n=1..=70, thresholds
{4,5,8}, all three MatU variants, V absent/present, f32/f64, rank-one and
nonzero bidiagonal fixtures, aligned and odd-address stacks. Each stack slice
has exactly size_bytes() at the required alignment or unaligned_bytes_required()
bytes at an odd address. It checks finite outputs, the rank-one spectrum,
Frobenius norm and factor orthogonality where applicable.

The rayon test executes 264 Full+V calls in a two-thread pool with the same
thresholds/types/fixtures/stack alignments at n={4,5,7,8,9,15,16,17,63,64,65}.
The private solver requires n>=1; public empty-input tests and scan retain n=0.

## Failure evidence

- regression-red.log: the original public regression command
  `cargo test -p t4a-faer --lib --locked --offline test_v_only_rank_one_exact_scratch -- --nocapture`
  on baseline plus the test, before the correction: exit 101, reported
  two-usize allocation panic at bidiag_svd.rs:574.
- internal-red.log: same internal-test command as above with the original
  scratch query restored. Exit 101: the sequential test fails on a secular-merge
  column allocation; the rayon test passes.
- baseline-ordinary-workspace.log: earlier baseline workspace run, showing
  the same three strict-triangle matmul failures.

## Initial candidate checks retained

These checks passed before the equivalent max(k, rem)/parameter-name cleanup
and addition of the internal tests. They were not repeated for those changes.

| Log | Command | Result |
| --- | --- | --- |
| integration.log | `cargo test --workspace --test '*' --locked --offline` | Exit 0, 25 tests pass. |
| public-bidiagonal.log | `cargo test -p t4a-faer --test public_bidiagonal_svd --locked --offline` | Exit 0, 6 tests pass. |
| doctests.log | `cargo test --workspace --doc --locked --offline` | Exit 0, 60 tests pass. |
| traits.log | `cargo test -p t4a-faer-traits --lib --locked --offline` | Exit 0, 1 test passes. faer-macros has zero tests and passes in workspace-review.log. |
| build-std.log | `cargo build -p t4a-faer --no-default-features --features std --locked --offline` | Exit 0, existing warnings retained. |

## Scratch-only reproduction

Only the scratch scan remains under repro/. Change its Cargo.toml faer path to
the candidate checkout. It has no EVD or triangular-solve entry points.

```
cargo build --locked --offline --manifest-path repro/Cargo.toml
<CARGO_TARGET_DIR>/debug/lapack-investigation-repro
```

scratch-only-build.log records the initial build and pruning of unused lockfile
entries after trimming the project. scratch-only-locked-build.log verifies the
archived lock with the command above. scratch-only-scan.log records exit 0:
4,800 success records, 1,200 per type. Source asserts successful return and finite
requested outputs after every call. This scan is sequential throughout.

- Dimensions: 0,1,2,3,4,5,7,8,9,15,16,17,31,32,33,63,64,65,126,127,128,129,255,256,257.
- Thresholds: 0,1,3,4,5,8,16,32,64,127,128,129.
- Four U/V presence combinations, f32/c32/f64/c64, exact public scratch with
  no extra padding.

The scan establishes allocation sufficiency and finiteness for these cases;
numerical validation is in the ordinary regression, internal tests and LAPACK
suite. Other platforms and the full opt-in non-SVD suite were not rerun.
