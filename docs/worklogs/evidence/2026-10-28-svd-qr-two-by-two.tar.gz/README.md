# Bidiagonal QR two-by-two exit #81: local evidence

Baseline: tensor4all/faer main 2592bad8cef0bbba00d1ae31c0442ea6cf3c5310.
Candidate: uncommitted; source.patch includes both existing source files and
the new qr_stall.rs fixture/test module. No #73/#74 fixes are included.
Current host/compiler: aarch64-apple-darwin, Homebrew Rust 1.98.1, LLVM 22.1.8.
The reporter's Rust 1.99.0 release configuration was not run.

The original 12x10 fixture passes before and after on this build. The internal
3x3 one-ulp-pair reproducer fails with NoConvergence before and passes afterward.
That is the local failure proof; no claim that the dense fixture fails on this
compiler/profile is made. Matrix noise entries are preserved exactly.

Commands run from the faer workspace with:

```
CARGO_TARGET_DIR=/Users/pzb464/Documents/faer/target
CARGO_PROFILE_DEV_DEBUG=0
CARGO_INCREMENTAL=0
```

| Log | Command | Result |
| --- | --- | --- |
| baseline-workspace.log | `cargo test --workspace --locked --offline` | Baseline exit 101: 459 faer passes, three matmul failures, 138 ignored. |
| regression-red.log | `cargo test -p t4a-faer --lib --locked --offline issue81 -- --nocapture` | Exit 101 before correction: internal pair fails NoConvergence, public matrix coverage passes. |
| regression-green-final.log | Same focused command | Exit 0 after correction, both tests pass. The additional final subnormal assertion is covered in the final workspace log below. |
| workspace-with-subnormal.log | `cargo test --workspace --locked --offline` | Final source exit 101: 461 faer passes, the same three baseline matmul failures, 138 ignored. Includes the final subnormal assertion. |
| svd-lapack-final.log | `cargo test --workspace --lib --locked --offline linalg::svd::tests:: -- --include-ignored --nocapture --test-threads=1` | Exit 101: 75 pass and three pre-existing failing groups; 18,172 LAPACK calls attempted. |
| baseline-svd.log | Earlier SVD run at the same baseline revision | 74 pass, same three failing groups. Retained historical evidence; compiler/profile details are in baseline-environment.log. |
| integration.log | `cargo test --workspace --test '*' --locked --offline` | Exit 0, 25 tests pass. |
| doctests.log | `cargo test --workspace --doc --locked --offline` | Exit 0, 60 tests pass. |
| traits.log | `cargo test -p t4a-faer-traits --lib --locked --offline` | Exit 0, one test passes. faer-macros has zero tests and passes in workspace runs. |
| build-std.log | `cargo build -p t4a-faer --no-default-features --features std --locked --offline` | Exit 0, existing warnings retained. |
| format-baseline.log / format-final.log | `rustfmt --edition 2021 --config-path rustfmt.toml --config skip_children=true --check <changed Rust files>` | Same three legacy formatting differences; after removing file/line headings, reports match. New module and changed blocks introduce no differences. |

SVD/integration checks use the same final production implementation. The final
ordinary run additionally includes the last test-only subnormal-value assertion.

The two focused tests perform 225 sequential calls:

- 96 real-kernel calls: six f32/f64 pair/sign/conditioning cases x four scales
  x four vector-output choices. Checks cover spectrum, zeroed subdiagonal,
  orthogonality and reconstruction where vectors are returned.
- One extra f64 kernel call preserves a subnormal singular value with an
  independent MIN_POSITIVE/sqrt(2) oracle; multiplying f*h first would lose
  precision before division by the larger singular value.
- 128 public complex calls: two types x four scales x A/adjoint x default/max
  recursion thresholds x four vector-output choices. The original fixture has
  sixty nonzero pairs, including twelve small noise entries; sixty explicit
  zeros are omitted from Rust storage.

Known failures retained:

- linalg::matmul::internal::tests::empty_strict_triangle_preserves_parent_guards
- linalg::matmul::internal::tests::strict_triangle_maps_preserve_stored_entries_and_parent_guards
- linalg::matmul::internal::tests::strict_triangle_preserves_nonempty_parent_guards
- linalg::svd::tests::lapack_svd_f32::lapack::rank_one_at_recursion_splits (#73)
- linalg::svd::tests::lapack_svd_c32::lapack::rank_one_at_recursion_splits (#73)
- linalg::svd::tests::lapack_svd_f32::lapack::bidiagonal_family (#75)

The SVD run records two existing scratch call failures and three other numerical
diagnostics in the known #75 group; no new failing groups appear.

## Independent LAPACK check and fixture provenance

Source: https://github.com/tensor4all/faer/issues/81, by maxsroda, 2026-10-28.
reference/matrix.json retains all 120 original entries as decimal strings.
The archive was generated only after verifying that all 120 pairs match the
Rust fixture bit-for-bit as f64, including its sixty implicit zeros.

```
/usr/bin/python3 reference/oracle.py reference/matrix.json
```

independent-lapack.log records NumPy 1.26.4 / SciPy 1.13.0, gesvd and gesdd.
Both agree on the leading eight singular values and give relative residual
about 8.2e-16. The small trailing values differ from the reporter's provider;
their relative accuracy is not asserted at the roundoff scale.

No deflation tolerance or iteration budget was relaxed. No upstream faer
checkout was measured, no upstream feedback was sent, and no commit/PR/release
was made for this fix. Other platforms, the reported release/toolchain pair,
the full opt-in non-SVD suite and benchmark acceptance remain unverified.
