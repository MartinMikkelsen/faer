import json
import sys
from pathlib import Path

import numpy as np
import scipy
from scipy.linalg import svd

rows = json.loads(Path(sys.argv[1]).read_text())
a = np.zeros((12, 10), dtype=np.complex128)
for row in rows:
    a[row['i'], row['j']] = complex(float(row['re']), float(row['im']))
expected = np.array([
    3.9414676652919867, 3.9414676652919858,
    0.48150883185813453, 0.48150883185813415,
    0.11330659717393496, 0.11330659717393492,
    0.011919830114133985, 0.011919830114133898,
])
print('numpy', np.__version__, 'scipy', scipy.__version__)
for driver in ['gesvd', 'gesdd']:
    u, s, vh = svd(a, full_matrices=False, lapack_driver=driver)
    residual = np.linalg.norm(a - (u * s) @ vh) / np.linalg.norm(a)
    assert residual < 1e-13
    assert np.max(np.abs(s[:8] - expected)) < 1e-13
    print(driver, 'singular_values', list(s))
    print(driver, 'relative_residual', residual)
