# Triangular subnormal pivot fix #74: correctness evidence

Baseline: tensor4all/faer main 2592bad8cef0bbba00d1ae31c0442ea6cf3c5310.
Candidate: uncommitted; source.patch contains the final implementation and tests.
Host/compiler: aarch64-apple-darwin, Rust 1.96.0, LLVM 22.1.2.
No changes from the separate #73 worktree are included.

All commands run from the faer workspace with:

```
CARGO_TARGET_DIR=/Users/pzb464/Documents/faer/target
CARGO_PROFILE_DEV_DEBUG=0
CARGO_INCREMENTAL=0
```

| Log | Command | Result |
| --- | --- | --- |
| baseline-workspace.log | `cargo test --workspace --locked --offline` | Baseline: exit 101, 459 faer passes, three strict-triangle matmul failures, 138 ignored. |
| regression-red.log | `cargo test -p t4a-faer --lib --locked --offline linalg::triangular_solve::tests::subnormal -- --nocapture` | Before the fix: exit 101, all three new regressions fail with Inf/NaN instead of one. |
| workspace-final.log | `cargo test --workspace --locked --offline` | Final source: exit 101, 462 faer passes, same three matmul failures, 138 ignored. Includes all three new regressions. |
| triangular-lapack-final.log | `cargo test --workspace --lib --locked --offline linalg::triangular_solve:: -- --include-ignored --nocapture --test-threads=1` | Exit 0, 33 tests pass. All 11,472 configured LAPACK calls attempted with no call failures or diagnostics. |
| integration.log | `cargo test --workspace --test '*' --locked --offline` | Exit 0, 25 tests pass. |
| doctests.log | `cargo test --workspace --doc --locked --offline` | Exit 0, 60 tests pass. |
| traits.log | `cargo test -p t4a-faer-traits --lib --locked --offline` | Exit 0, one test passes. faer-macros has zero tests and passes in the workspace run. |
| build-std.log | `cargo build -p t4a-faer --no-default-features --features std --locked --offline` | Exit 0, existing warnings retained. |
| format-baseline.log / format-final.log | `rustfmt --edition 2021 --config-path rustfmt.toml --config skip_children=true --check <triangular_solve.rs>` | Exit 0 on baseline and final source. |

The ordinary tests execute 3,744 sequential public calls: 36 pivot/fixture
configurations x 13 dimensions x 2 triangle directions x 2 conjugations x
2 RHS layouts. Every call has two RHS columns and the literal expected solution
one for every entry. The dimensions are 1,2,3,4,5,8,16,17,32,64,65,128,129.

The fixture configurations consist of twelve real diagonal cases (two types,
three scales and both signs), eighteen complex diagonal cases (two types,
three scales and real/imaginary/mixed phases), and six coupled bidiagonal cases
alternating a smallest-subnormal pivot with a huge pivot. Diagonal scales are
the smallest subnormal, MIN_POSITIVE/2 and one. Coupled matrices have zero
interior RHS, so normalizing coefficients first can break a finite solution;
the expected solution is derived independently as a constant one.

The LAPACK total is four types x (2,832 triangular calls + 36 parallel-path
calls). The latter includes sequential reference and 2T/4T runs. Existing guarded
views, input immutability and unit-diagonal NaN sentinels pass. The unit-diagonal
base kernel is byte-identical to baseline.

The three remaining failures are:

- linalg::matmul::internal::tests::empty_strict_triangle_preserves_parent_guards
- linalg::matmul::internal::tests::strict_triangle_maps_preserve_stored_entries_and_parent_guards
- linalg::matmul::internal::tests::strict_triangle_preserves_nonempty_parent_guards

Apply source.patch to the baseline to reproduce the focused checks. These are
local correctness results, not benchmark acceptance. Other platforms and the
full opt-in non-triangular LAPACK suite were not checked. No upstream checkout
was measured and no commit, PR or release was made for this fix.
