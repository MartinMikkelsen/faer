from decimal import Decimal as D,localcontext
from pathlib import Path
v=Path('/private/tmp/faer-lapack-program/eigenvector-reference.txt').read_text().split();n=int(v[0]);v=list(map(lambda x:D.from_float(float(x)),v[1:]));a=[v[i*n:(i+1)*n] for i in range(n)];k=n*n;wr=v[k:k+2*n:2];wi=v[k+1:k+2*n:2];k+=2*n;x=[v[k+i*n:k+(i+1)*n] for i in range(n)]
def decoded(i,j):
 if wi[j]>0:return x[i][j],x[i][j+1]
 if wi[j]<0:return x[i][j-1],-x[i][j]
 return x[i][j],D(0)
with localcontext() as ctx:
 ctx.prec=80
 an=max(sum(abs(a[i][j]) for i in range(n)) for j in range(n));xn=D(0);err=D(0)
 for j in range(n):
  col=D(0);xc=D(0)
  for i in range(n):
   re,im=decoded(i,j); rr=-(re*wr[j]-im*wi[j]);ri=-(re*wi[j]+im*wr[j]);xc+=(re*re+im*im).sqrt()
   for kk in range(n):
    r,ii=decoded(kk,j);rr+=a[i][kk]*r;ri+=a[i][kk]*ii
   col+=(rr*rr+ri*ri).sqrt()
  err=max(err,col);xn=max(xn,xc)
 ratio=err/an/xn/D.from_float(2.0**-52)
 text=f'n={n}\nreference_precision=80 decimal digits\nresidual_norm1={err}\nA_norm1={an}\nX_norm1={xn}\nnormalized_ratio={ratio}\n'
 Path('/private/tmp/faer-lapack-program/phase2-high-precision.txt').write_text(text);print(text)
